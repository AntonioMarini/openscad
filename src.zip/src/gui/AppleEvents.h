#pragma once

void installAppleEventHandlers();
