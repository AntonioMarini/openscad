#pragma once

bool initializeGlew();
